#include <stdlib.h>
#include "item.h"
#include "queue-2stack.h"
#include "stack.h"

struct queue
{

};


Queue newQueue()
{
	Queue q = malloc(sizeof(struct queue));

	return q;
}


int isEmptyQueue(Queue q) {
}
void enqueue(Queue q, Item i) {
}
Item dequeue(Queue q) {

}

void reverseQueue(Queue q) {
}
