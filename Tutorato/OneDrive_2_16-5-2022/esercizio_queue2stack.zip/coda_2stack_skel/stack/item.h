typedef void *Item;

Item inputItem ();
void outputItem (Item);
int compareItem (Item, Item);
