#include <stdlib.h>
#include <stdio.h>
#include "item.h"
#define MAX 100
#define DIM 20

typedef struct auto_struct{
	  int matricola;
	  float costo;
} Automobile;

Item inputItem(){
	// TODO
}

void outputItem(Item X){
	// TODO
}

int compareItem(Item a1, Item a2){

	// TODO

}

