#include <stdio.h>
#include "item.h"
#include "list.h"

#define DIM 8

int main(){
	int i;
	int pos=0;
	Item item;
	List l = newList(),m;
	for(i=0;i<3;i++)
	{
		item = inputItem();
		addListTail(l, item);
	}
	printList(l);

	// rimuoviamo una automobile
	Item toRemove;
	toRemove=inputItem();
	toRemove = searchList(l,toRemove,&pos);

	printf("Posizione item %d",pos);

	if (toRemove!=NULL) {
		printf("Item trovato\n\n");
		removeListItem(l,toRemove);
		printf("NUOVA LISTA\n");
		printList(l);
	}

	// completare con la rimozione dell'auto


	return 0;
}
